import binascii
import os

path = "D:\\Development\\Softwares\\MobaXterm\\23.2_preview\\zh"
input_file_name = "MobaXterm_Personal_23.2_Preview1_CHS.exe"
output_file_name = "2MobaXterm_Personal_23.2_Preview1_CHS.exe"

translate_file_name = "D:\\Development\\Softwares\\MobaXterm\\rdmp\\translate.ini"

# 打开要修改的exe文件
with open(os.path.join(path,input_file_name), 'rb') as f:
    data = bytearray(f.read())

# 读取translate.ini文件并进行数据替换
with open(translate_file_name, 'r') as f:
    for line in f:
        # 按|分隔数据对
        src, dest = line.strip().split('|')
        # 将16进制字符串转换成字节数组
        src_bytes = binascii.unhexlify(src)
        dest_bytes = binascii.unhexlify(dest)
        # 在data中搜索并替换数据对
        offset = 0
        while True:
            # 在偏移量offset处开始搜索
            offset = data.find(src_bytes, offset)
            if offset == -1:
                # 没有找到，退出循环
                break
            # 找到了，将原始数据替换为目标数据
            print('找到一处，替换中...')
            data[offset:offset+len(src_bytes)] = dest_bytes
            # 移动偏移量到替换后的位置，避免重复替换
            offset += len(dest_bytes)

# 输出修改后的exe文件
with open(os.path.join(path,output_file_name), 'wb') as f:
    f.write(data)