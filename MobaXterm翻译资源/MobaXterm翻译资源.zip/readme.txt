新增python替换脚本，平替aardio脚本

rdmp
	文件为 Radialix 的翻译库文件，针对不同的exe程序对应连接即可。
tmx 
	文件是 sisulizer 翻译文件，新建翻译项目后导入对应的 tmx 即可自动翻译

translate.ini 
	文件是使用ultraEdit 进行搜索替换的，将设置中针对工具栏的文本汉化。(12.4、12.5目前都支持)。使用|隔开，每行一对翻译。 可以自行编写程序或脚本替换。
	此处提供 Mobaxterm.aardio 脚本，使用 aardio 修改对应路径后执行即可自动翻译hex部分。


建议翻译全部做完后再执行搜索替换。sisulizer 翻译会导致程序部分界面变小，目前发现主界面和定制界面布局变小，没法调整回来。


翻译流程：
1、sisulizer4	
	新建翻译项目，导入Mobaxterm.exe
	导入 MobaXterm_Personal.tmx 完成自动翻译
	构建翻译后项目生成zh文件夹

2、radialix3 
	新建翻译项目，导入1中的zh文件夹下exe
	连接radialix_Mobaxterm_v2.rdmp
	配置 项目-->自动翻译，关闭模糊翻译 和 取消忽略各种控制符，匹配100%，防止模糊翻译出错。
	翻译即可。
	针对部分界面 和 hardcode 需要CTRL+K切换之后再翻译，因为内容是只读的默认无法翻译。
	RT_RCDATA -- TFORMXTERM 和 TFORMPORTFORWARDINGEDIT,需要切换只读后翻译，再切换回来
	
如有问题可以邮件联系我

aardio 下载地址
https://ide.update.aardio.com/releases/aardio.7z

anysoft@yeah.net

不建议翻译字段：
Edit
Delete
Renae
Name
Color
Size
Font

Browse

OK

Cancel
Duplicate

Yes
No
Close
Owner
All
None
Background
